from kivymd.uix.boxlayout import MDBoxLayout

class AppBar(MDBoxLayout):
    '''appbar'''
