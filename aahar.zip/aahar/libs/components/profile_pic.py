from kivy.properties import StringProperty
from kivymd.uix.card import MDCard


class Profile_pic(MDCard):
    avatar = StringProperty()
