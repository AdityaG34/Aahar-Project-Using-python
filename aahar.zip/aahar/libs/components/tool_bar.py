from kivymd.uix.boxlayout import MDBoxLayout
from kivy.lang.builder import Builder





class Menu(MDBoxLayout):
    '''menubar'''